void main() {
   TRISB=0x00;
     portb=0x00;
     
     
     while(1){
     
        portb.f0=0xff;
        portb.f1=0x00;
        
     
     }
     
     
}